<?php
    header('location: frontend/index.php')
?>